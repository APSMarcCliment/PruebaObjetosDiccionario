﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebaObjetosDiccionario
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            Coche coche1 = new Coche("Ferrari", 1234, 120, "Rosa", false, 1);
            Coche coche2 = new Coche("Alpine", 7436, 130, "Azul", true, 2);
            Coche coche3 = new Coche("Mclaren", 8473, 110, "Verde", true, 3);
            Coche coche4 = new Coche("Mercedes", 0294, 100, "Amarillo", false, 1);

            List<Coche> coches = new List<Coche>();
            coches.Add(coche1);
            coches.Add(coche2);
            coches.Add(coche3);
            coches.Add(coche4);

            Dictionary<int, Coche> carList = new Dictionary<int, Coche>();

            for(int i = 0; i < coches.Count; i++)
            {
                carList.Add(coches[i].getMatricula(), coches[i]);
            }

        }
    }
}
